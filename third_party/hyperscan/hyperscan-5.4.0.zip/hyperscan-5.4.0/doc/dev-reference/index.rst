###############################################
Hyperscan |version| Developer's Reference Guide
###############################################

-------
|today|
-------

.. toctree::
   :maxdepth: 2

   copyright
   preface
   intro
   getting_started
   compilation
   runtime
   serialization
   performance
   tools
   api_constants
   api_files
   chimera
