#warning "urcu/urcu-futex.h is deprecated. Please include urcu/futex.h instead."
#include <urcu/futex.h>
